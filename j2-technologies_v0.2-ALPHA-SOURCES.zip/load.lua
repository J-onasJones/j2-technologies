function love.load()
    --Configure table
    table.has = function(tabl, value)
        for i,v in pairs(tabl) do
            if value == item then return true end
        end
        return false
    end
    
    table.length = function(tabl)
        local count = 0
        for i,v in pairs(tabl) do
            count = count + 1
        end
        return count
    end
    --Load Variables
	love.window.setFullscreen(true, "desktop")
	launchimg = love.graphics.newImage("src/launch.png")
    homemini = love.graphics.newImage("src/homemini.png")
    home = love.graphics.newImage("src/home.png")
    homeexpdwon = love.graphics.newImage("src/homeexpdown.png")
    homeselect1 = love.graphics.newImage("src/homeselect1.png")
    homeselect2 = love.graphics.newImage("src/homeselect2.png")
    homeselect3 = love.graphics.newImage("src/homeselect3.png")
    homeselect4 = love.graphics.newImage("src/homeselect4.png")
	width = love.graphics.getWidth()
	height = love.graphics.getHeight()
	timer = 0
	timer1 = 0
    guiscale = 5
    guifactor = guiscale / 5
	launchimgsx = love.graphics:getWidth() / launchimg:getWidth()
	launchimgsy = love.graphics:getHeight() / launchimg:getHeight()
    homeminisx = guifactor / 10
	homeminisy = guifactor / 10
	debug = true
	pixels = {}
end