require "load"
require "draw"

function love.update(dt)
	timer = timer + dt
	timer1 = timer1 + dt
	pos = {love.mouse.getX(), love.mouse.getY()}
	if(love.mouse.isDown(0))then
		pixels = {}
	end
	
	for i,v in ipairs(pixels) do
		if(table.has(pixels, v))then
			v = nil
		end
	end
	
	if(love.mouse.isDown(1))then
		table.insert(pixels, pos)
	end
end