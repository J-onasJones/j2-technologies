table.has = function(tabl, value)
	for i,v in pairs(tabl) do
		if value == item then return true end
	end
	return false
end

table.length = function(tabl)
	local count = 0
	for i,v in pairs(tabl) do
		count = count + 1
	end
	return count
end