function love.draw()
	if timer < 3 then
		love.graphics.draw(launchimg, 0, 0, 0, launchimgsx, launchimgsy)
		timer1 = 0
	end
	if timer1 < 1 then
		alpha = 1 - timer1
		love.graphics.setColor(255, 255, 255, alpha)
		love.graphics.draw(launchimg, 0, 0, 0, launchimgsx, launchimgsy)
	end
	if timer > 3 then
		love.graphics.setColor(255,255,255)
		for i,v in ipairs(pixels) do
			love.graphics.circle("fill", v[1], v[2], 4)
		end
        love.graphics.draw(homemini, 20*guifactor, 20*guifactor, 0, homeminisx, homeminisy)
	end
    if debug then
        love.graphics.print("FPS: "..love.timer.getFPS(), 10, height - 15)
        love.graphics.print("EntityCount: "..table.length(pixels), 10, height - 30)
    end
end